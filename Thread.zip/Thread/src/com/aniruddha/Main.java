package com.aniruddha;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccountDetails a2= new AccountDetails();
		Thread t1= new Thread(a2);
		Thread t2= new Thread(a2);
		
		t1.setName(" Aniruddha ");
		t2.setName("Kamble");
		
		t1.start();
		t2.start();
	}

}
