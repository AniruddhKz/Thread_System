package com.aniruddha;

public class AccountDetails implements Runnable {
	
	Account a= new Account();

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1; i<=10; i++) {
			transaction(1000, i);
			if(a.getBalance()<=0) {
				System.out.println(" data : 1 ");
			}
		}
		
	}

	private void transaction(int amount, Object AccountDetails) {
		// TODO Auto-generated method stub
		synchronized(AccountDetails ) {
			if(a.getBalance()>=amount) {
				System.out.println(amount);
			}
			
			try {
				Thread.sleep(2000);
			}
			catch(Exception e) {
			 e.printStackTrace();
			}
			
			
			int balance= a.afterWithdraw(amount);
			System.out.println(Thread.currentThread().getName()+ "  "  +balance);
		}
		
	}
	

}
