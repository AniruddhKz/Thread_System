package com.aniruddha;

public class Account {
	
	private int balance=20;
	
	public int getBalance() {
		return this.balance;
	}
	
	public int afterWithdraw(int amount) {
		balance= balance-amount;
		return balance;
	}

}
